// @flow

export SCREEN_SIZE = {
  height: props => props.theme.height,
  width: props => props.theme.width,
  topBuffer: props => props.theme.topBuffer,
  bottomBuffer: props => props.theme.bottomBuffer,
}
